# jetson-utils
C/C++ wrapper Linux utilities for NVIDIA Jetson TX1/TX2 - camera, HID, GStreamer, CUDA, OpenGL/XGL
